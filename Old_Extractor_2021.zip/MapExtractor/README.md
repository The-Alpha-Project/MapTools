# MapExtractor
To use this extraction tool, make sure to rename `Config.ini.dist` file to `Config.ini`. After that, use a valid path linking to your 0.5.3 game installation.

